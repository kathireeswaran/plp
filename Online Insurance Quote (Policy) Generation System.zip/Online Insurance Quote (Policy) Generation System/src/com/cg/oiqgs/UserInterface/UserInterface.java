/**
 * 
 */
package com.cg.oiqgs.UserInterface;

import java.util.List;
import java.util.Scanner;

import com.cg.oiqgs.exception.OiqgsException;
import com.cg.oiqgs.mainclass.Agent;
import com.cg.oiqgs.mainclass.Insured;
import com.cg.oiqgs.mainclass.UnderWriter;
import com.cg.oiqgs.model.UserRole;
import com.cg.oiqgs.service.InsuranceQuotesService;
import com.cg.oiqgs.serviceImpl.InsuranceQuotesServiceImpl;
import com.cg.oiqgs.supportingClass.Account;
import com.cg.oiqgs.supportingClass.ViewPolicy;

/**
 * @author :Capgemini Date :04-Feb-2018
 *
 */
public class UserInterface {

	/**
	 * @param args
	 */

	@SuppressWarnings({ "resource", "static-access" })
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String rolecode = null;
		boolean validateFlag = false;
		InsuranceQuotesService service = new InsuranceQuotesServiceImpl();
		do {
			System.out.println("Enter Username");
			String userName = scanner.nextLine();
			System.out.println("Enter Password");
			String password = scanner.nextLine();
			Account account = new Account();
			ViewPolicy policy = new ViewPolicy();

			try {
				List<UserRole> role = service.getValidate(userName, password);
				if (!role.isEmpty()) {
					account.getUserName(userName);

					policy.getUserName(userName);
					for (UserRole userRole : role) {
						rolecode = userRole.getRoleCode();
					}
					account.getRoleCode(rolecode);
					policy.getRoleCode(rolecode);
					if (rolecode.equalsIgnoreCase("Insured")) {
						validateFlag = true;
						Insured insured = new Insured();
						insured.main(null);
					} else if (rolecode.equalsIgnoreCase("Agent")) {
						validateFlag = true;
						Agent agent = new Agent();
						agent.main(null);
					} else if (rolecode.equalsIgnoreCase("admin")) {
						validateFlag = true;
						UnderWriter underWriter = new UnderWriter();
						underWriter.main(null);
					}
				} else {
					System.err.println("username/password is mismatch");
				}
			} catch (OiqgsException e) {
				System.err.println("error occured in password validation");
			}
		} while (!validateFlag);

	}

}
