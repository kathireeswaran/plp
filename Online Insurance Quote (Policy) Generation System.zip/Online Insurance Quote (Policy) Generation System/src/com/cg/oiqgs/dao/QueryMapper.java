package com.cg.oiqgs.dao;

public interface QueryMapper {
	public static final String userCheck = "select rolecode from User_role where username=? and password=?";
	public static final String validUser = "select username from User_role where username=?";
	public static final String insertUser = "insert into user_role values(?,?,?)";
	public static final String insertAccount = "insert into accounts values(account_number_seq.nextval,?,?,?,?,?,?)";
	public static final String AccountNumber = "select account_number_seq.currval from dual";
	public static final String validAccount = "select account_Number from accounts where account_Number=?";
	public static final String businessSegment = "select * from businessSegment";
	public static final String questions = "select * from policyQuestions where bus_seg_id=?";
	public static final String policyInsert = "insert into policy values(policy_number.nextval,?,?,?)";
	public static final String policyNumber = "select policy_number.currval from dual";
	public static final String policyDetails = "insert into policydetails values(?,?,?,?)";
	public static final String getPolicyDetails = "select p.policy_number,p.business_segment,p.policy_premium,p.account_number from user_role u,accounts a,policy p where u.username=a.username and a.account_number=p.account_number and u.username=?";
	public static final String checkAccount = "Select INSURED_NAME from accounts where USERNAME=?";
	public static final String getReport = "select a.insured_name,a.insured_street,a.insured_city,a.insured_state,a.insured_zip,p.business_segment, d.POLICY_QUESTION,d.answer,p.policy_premium from accounts a,policy p,policydetails d where a.account_number=p.account_number and p.policy_number=d.policy_number and a.account_number=?";
	public static final String getAllPolicyDetails = "select p.policy_number,p.business_segment,p.policy_premium,p.account_number from policy p ";
}
