package com.cg.oiqgs.supportingClass;

import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.oiqgs.exception.OiqgsException;
import com.cg.oiqgs.model.AccountCreation;
import com.cg.oiqgs.service.InsuranceQuotesService;
import com.cg.oiqgs.serviceImpl.InsuranceQuotesServiceImpl;

public class Account {
	static String userName;
	static String roleCode;

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		boolean doFlag = false;
		Scanner scanner = new Scanner(System.in);
		String insuredName;
		if (roleCode.equalsIgnoreCase("Agent") || roleCode.equalsIgnoreCase("Admin")) {
			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter InsuredName:");
				insuredName = scanner.nextLine();
				String regexname = "[a-zA-Z0-9]*";
				boolean valid = Pattern.matches(regexname, insuredName);
				if (valid == true)
					doFlag = true;
				else
					System.err.println("ENTER VALID NAME");
			} while (!doFlag);
			doFlag = false;
			String insuredStreet;
			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter insuredStreet:");
				insuredStreet = scanner.nextLine();
				String regexname = "[a-zA-Z0-9]*";
				boolean valid = Pattern.matches(regexname, insuredStreet);
				if (valid == true)
					doFlag = true;
				else
					System.err.println("ENTER VALID Street");
			} while (!doFlag);
			doFlag = false;
			String insuredCity;
			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter insuredCity:");
				insuredCity = scanner.nextLine();
				String regexname = "[a-zA-Z0-9]*";
				boolean valid = Pattern.matches(regexname, insuredCity);
				if (valid == true)
					doFlag = true;
				else
					System.err.println("ENTER VALID City");
			} while (!doFlag);
			doFlag = false;
			String insuredState;
			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter insuredState:");
				insuredState = scanner.nextLine();
				String regexname = "[a-zA-Z0-9]*";
				boolean valid = Pattern.matches(regexname, insuredState);
				if (valid == true)
					doFlag = true;
				else
					System.err.println("ENTER VALID State");
			} while (!doFlag);
			doFlag = false;
			String zip;
			int insuredZip;
			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter insuredZip:");
				zip = scanner.nextLine();
				String regexname = "[0-9]{5}";
				insuredZip = Integer.parseInt(zip);
				boolean valid = Pattern.matches(regexname, zip);
				if (valid == true)
					doFlag = true;
				else
					System.err.println("ENTER VALID Zip");
			} while (!doFlag);
			AccountCreation accountCreation = new AccountCreation();
			accountCreation.setInsuredName(insuredName);
			accountCreation.setInsuredStreet(insuredStreet);
			accountCreation.setInsuredCity(insuredCity);
			accountCreation.setInsuredState(insuredState);
			accountCreation.setInsuredZip(insuredZip);
			accountCreation.setUserName(userName);
			InsuranceQuotesService service = new InsuranceQuotesServiceImpl();
			try {
				long accountNumber = service.insertAccount(accountCreation);
				System.out.println("YOUR ACCOUNT NO:" + accountNumber);
			} catch (OiqgsException e) {
				e.printStackTrace();
			}
		} else {
			InsuranceQuotesService service = new InsuranceQuotesServiceImpl();
			boolean validInsured = false;
			try {
				validInsured = service.checkinsured(userName);
			} catch (OiqgsException e1) {
				e1.printStackTrace();
			}
			if (validInsured == true) {
				do {
					scanner = new Scanner(System.in);
					System.out.println("Enter InsuredName:");
					insuredName = scanner.nextLine();
					String regexname = "[a-zA-Z0-9]*";
					boolean valid = Pattern.matches(regexname, insuredName);
					if (valid == true)
						doFlag = true;
					else
						System.err.println("ENTER VALID NAME");
				} while (!doFlag);
				doFlag = false;
				String insuredStreet;
				do {
					scanner = new Scanner(System.in);
					System.out.println("Enter insuredStreet:");
					insuredStreet = scanner.nextLine();
					String regexname = "[a-zA-Z0-9]*";
					boolean valid = Pattern.matches(regexname, insuredStreet);
					if (valid == true)
						doFlag = true;
					else
						System.err.println("ENTER VALID Street");
				} while (!doFlag);
				doFlag = false;
				String insuredCity;
				do {
					scanner = new Scanner(System.in);
					System.out.println("Enter insuredCity:");
					insuredCity = scanner.nextLine();
					String regexname = "[a-zA-Z0-9]*";
					boolean valid = Pattern.matches(regexname, insuredCity);
					if (valid == true)
						doFlag = true;
					else
						System.err.println("ENTER VALID City");
				} while (!doFlag);
				doFlag = false;
				String insuredState;
				do {
					scanner = new Scanner(System.in);
					System.out.println("Enter insuredState:");
					insuredState = scanner.nextLine();
					String regexname = "[a-zA-Z0-9]*";
					boolean valid = Pattern.matches(regexname, insuredState);
					if (valid == true)
						doFlag = true;
					else
						System.err.println("ENTER VALID State");
				} while (!doFlag);
				doFlag = false;
				String zip;
				int insuredZip;
				do {
					scanner = new Scanner(System.in);
					System.out.println("Enter insuredZip:");
					zip = scanner.nextLine();
					String regexname = "[0-9]{5}";
					insuredZip = Integer.parseInt(zip);
					boolean valid = Pattern.matches(regexname, zip);
					if (valid == true)
						doFlag = true;
					else
						System.err.println("ENTER VALID Zip");
				} while (!doFlag);

				AccountCreation accountCreation = new AccountCreation();
				accountCreation.setInsuredName(insuredName);
				accountCreation.setInsuredStreet(insuredStreet);
				accountCreation.setInsuredCity(insuredCity);
				accountCreation.setInsuredState(insuredState);
				accountCreation.setInsuredZip(insuredZip);
				accountCreation.setUserName(userName);

				try {
					long accountNumber = service.insertAccount(accountCreation);
					System.out.println("YOUR ACCOUNT NO:" + accountNumber);
				} catch (OiqgsException e) {
					e.printStackTrace();
				}
			} else {
				System.err.println("YOUR ALLOWED CREATE ONLY ONE ACCOUNT");
			}
		}
	}

	public void getUserName(String user) {
		userName = user;

	}

	public void getRoleCode(String rolecode) {
		roleCode = rolecode;

	}
}
