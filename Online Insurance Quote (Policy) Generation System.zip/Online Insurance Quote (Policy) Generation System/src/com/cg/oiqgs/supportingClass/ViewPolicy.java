package com.cg.oiqgs.supportingClass;

import java.util.List;
import java.util.Scanner;

import com.cg.oiqgs.exception.OiqgsException;
import com.cg.oiqgs.model.Policy;
import com.cg.oiqgs.service.InsuranceQuotesService;
import com.cg.oiqgs.serviceImpl.InsuranceQuotesServiceImpl;

public class ViewPolicy {
	static String userName;
	static String roleCode;

	@SuppressWarnings({ "resource", "unused" })
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		InsuranceQuotesService service = new InsuranceQuotesServiceImpl();

		try {
			List<Policy> list = null;
			if (roleCode.equalsIgnoreCase("Agent") || roleCode.equalsIgnoreCase("Insured"))
				list = service.getPolicyDetails(userName);
			else if (roleCode.equalsIgnoreCase("Admin"))
				list = service.getPolicyDetails();

			if (!(list.isEmpty())) {
				System.out.println("POLICY NUMBER" + "		" + "BUSINESS SEGMENT" + "		" + "POLICY PREMIUM"
						+ "		" + "ACCOUNT NUMBER");
				for (Policy policy : list) {
					System.out.println(policy.getPolicyNumber() + "		" + policy.getBussinessSegment() + "		"
							+ policy.getPolicyPremium() + "		" + policy.getAccountNumber());
				}
			} else
				System.err.println("NO DATA FOUND FOR GIVEN USER");
		} catch (OiqgsException e) {
			e.printStackTrace();
		}
	}

	public void getUserName(String user) {
		userName = user;
	}

	public void getRoleCode(String role) {
		roleCode = role;

	}

}
