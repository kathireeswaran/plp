package com.cg.oiqgs.serviceImpl;

import java.util.List;

import com.cg.oiqgs.dao.InsuranceQuotesDao;
import com.cg.oiqgs.daoimpl.InsuranceQuotesDaoImpl;
import com.cg.oiqgs.exception.OiqgsException;
import com.cg.oiqgs.model.AccountCreation;
import com.cg.oiqgs.model.Policy;
import com.cg.oiqgs.model.PolicyDetails;
import com.cg.oiqgs.model.Report;
import com.cg.oiqgs.model.UserRole;
import com.cg.oiqgs.service.InsuranceQuotesService;

public class InsuranceQuotesServiceImpl implements InsuranceQuotesService {

	InsuranceQuotesDao quotesDao = new InsuranceQuotesDaoImpl();

	@Override
	public List<UserRole> getvalidate(String userName, String password) throws OiqgsException {
		return quotesDao.getvalidate(userName, password);
	}

	@Override
	public boolean getUserValidation(String userName) throws OiqgsException {
		return quotesDao.getUserValidation(userName);
	}

	@Override
	public int insertProfile(UserRole role) throws OiqgsException {
		return quotesDao.insertProfile(role);
	}

	@Override
	public long insertAccount(AccountCreation accountCreation) throws OiqgsException {
		return quotesDao.insertAccount(accountCreation);
	}

	@Override
	public boolean getAccountValidation(long accountNumber) throws OiqgsException {
		// TODO Auto-generated method stub
		return quotesDao.getAccountValidation(accountNumber);
	}

	@Override
	public List<Policy> getBusinessSegment() throws OiqgsException {
		// TODO Auto-generated method stub
		return quotesDao.getBusinessSegment();
	}

	@Override
	public List<Policy> getQuestions(String segId) throws OiqgsException {
		// TODO Auto-generated method stub
		return quotesDao.getQuestions(segId);
	}

	@Override
	public long insertPolicy(Policy policy) throws OiqgsException {
		// TODO Auto-generated method stub
		return quotesDao.insertPolicy(policy);
	}

	@Override
	public int insertPolicyDetails(PolicyDetails details) throws OiqgsException {
		// TODO Auto-generated method stub
		return quotesDao.insertPolicyDetails(details);
	}

	@Override
	public List<Policy> getPolicyDetails(String userName) throws OiqgsException {
		// TODO Auto-generated method stub
		return quotesDao.getPolicyDetails(userName);
	}

	@Override
	public List<Report> getReport(long accountNumber) throws OiqgsException {
		// TODO Auto-generated method stub
		return quotesDao.getReport(accountNumber);
	}

	@Override
	public List<Policy> getPolicyDetails() throws OiqgsException {
		// TODO Auto-generated method stub
		return quotesDao.getPolicyDetails();
	}

	@Override
	public boolean checkinsured(String userName) throws OiqgsException {
		// TODO Auto-generated method stub
		return quotesDao.checkinsured(userName);
	}

}
