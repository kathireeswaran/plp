package com.cg.oiqgs.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.oiqgs.dao.InsuranceQuotesDao;
import com.cg.oiqgs.dao.QueryMapper;
import com.cg.oiqgs.exception.OiqgsException;
import com.cg.oiqgs.model.AccountCreation;
import com.cg.oiqgs.model.Policy;
import com.cg.oiqgs.model.PolicyDetails;
import com.cg.oiqgs.model.Report;
import com.cg.oiqgs.model.UserRole;
import com.cg.oiqgs.utility.JdbcUtility;

public class InsuranceQuotesDaoImpl implements InsuranceQuotesDao {
	PreparedStatement statement = null;
	Connection connection = null;
	long accountNum;

	@Override
	public List<UserRole> getvalidate(String userName, String password) throws OiqgsException {
		ResultSet resultSet = null;
		String roleCode;
		connection = JdbcUtility.getConnection();
		List<UserRole> list = new ArrayList<>();
		try {
			statement = connection.prepareStatement(QueryMapper.userCheck);
			statement.setString(1, userName);
			statement.setString(2, password);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				roleCode = resultSet.getString(1);
				UserRole role = new UserRole();
				role.setRoleCode(roleCode);
				list.add(role);
			}

		} catch (SQLException e) {
			System.err.println("SQL STATEMENT DOESNT EXECUTED");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new OiqgsException("proble in closing the statement");
			}
			try {
				connection.close();
			} catch (Exception e2) {
				throw new OiqgsException("connection is not closed");
			}
		}
		return list;
	}

	@Override
	public boolean getUserValidation(String userName) throws OiqgsException {
		ResultSet resultSet = null;
		List<UserRole> list1 = new ArrayList<>();
		boolean validFlag = false;
		connection = JdbcUtility.getConnection();

		try {
			statement = connection.prepareStatement(QueryMapper.validUser);
			statement.setString(1, userName);
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				String user = resultSet.getString(1);
				UserRole role = new UserRole();
				role.setUserName(user);
				list1.add(role);
			}

			if (list1.isEmpty()) {
				validFlag = true;
			}
		} catch (SQLException e) {
			System.err.println("SQL STATEMENT DOESNT EXECUTED");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new OiqgsException("proble in closing the statement");
			}
			try {
				connection.close();
			} catch (Exception e2) {
				throw new OiqgsException("connection is not closed");
			}
		}
		return validFlag;
	}

	@Override
	public int insertProfile(UserRole role) throws OiqgsException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		try {
			statement = connection.prepareStatement(QueryMapper.insertUser);
			statement.setString(1, role.getUserName());
			statement.setString(2, role.getPassword());
			statement.setString(3, role.getRoleCode());
			result = statement.executeUpdate();
		} catch (SQLException e) {
			System.err.println("SQL STATEMENT DOESNT EXECUTED");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new OiqgsException("proble in closing the statement");
			}
			try {
				connection.close();
			} catch (Exception e2) {
				throw new OiqgsException("connection is not closed");
			}
		}
		return result;
	}

	@Override
	public long insertAccount(AccountCreation accountCreation) throws OiqgsException {
		connection = JdbcUtility.getConnection();

		long accountNumber = 0;
		ResultSet resultSet = null;
		try {

			statement = connection.prepareStatement(QueryMapper.insertAccount);
			statement.setString(1, accountCreation.getInsuredName());
			statement.setString(2, accountCreation.getInsuredStreet());
			statement.setString(3, accountCreation.getInsuredCity());
			statement.setString(4, accountCreation.getInsuredState());
			statement.setInt(5, accountCreation.getInsuredZip());
			statement.setString(6, accountCreation.getUserName());
			statement.executeUpdate();
			statement = connection.prepareStatement(QueryMapper.AccountNumber);
			resultSet = statement.executeQuery();
			while (resultSet.next())
				accountNumber = resultSet.getLong(1);

		} catch (SQLException e) {
			System.err.println("SQL STATEMENT DOESNT EXECUTED");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new OiqgsException("proble in closing the statement");
			}
			try {
				connection.close();
			} catch (Exception e2) {
				throw new OiqgsException("connection is not closed");
			}
		}
		return accountNumber;
	}

	@Override
	public boolean getAccountValidation(long accountNumber) throws OiqgsException {
		ResultSet resultSet = null;
		List<Policy> list2 = new ArrayList<>();
		boolean validFlag = false;
		connection = JdbcUtility.getConnection();

		try {
			statement = connection.prepareStatement(QueryMapper.validAccount);
			statement.setLong(1, accountNumber);
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				long accountNumber1 = resultSet.getLong(1);
				Policy policy = new Policy();
				policy.setAccountNumber(accountNumber1);
				list2.add(policy);
			}

			if (!(list2.isEmpty())) {
				validFlag = true;
			}
		} catch (SQLException e) {
			System.err.println("SQL STATEMENT DOESNT EXECUTED");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new OiqgsException("proble in closing the statement");
			}
			try {
				connection.close();
			} catch (Exception e2) {
				throw new OiqgsException("connection is not closed");
			}
		}
		return validFlag;
	}

	@Override
	public List<Policy> getBusinessSegment() throws OiqgsException {
		List<Policy> list3 = new ArrayList<>();
		ResultSet resultSet = null;
		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.businessSegment);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				String busId = resultSet.getString(1);

				String busName = resultSet.getString(3);
				Policy policy = new Policy();
				policy.setBusSegId(busId);
				policy.setBusSegName(busName);
				list3.add(policy);
			}
		} catch (SQLException e) {
			System.err.println("SQL STATEMENT DOESNT EXECUTED");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new OiqgsException("proble in closing the statement");
			}
			try {
				connection.close();
			} catch (Exception e2) {
				throw new OiqgsException("connection is not closed");
			}
		}

		return list3;
	}

	@Override
	public List<Policy> getQuestions(String segId) throws OiqgsException {
		List<Policy> list4 = new ArrayList<>();
		ResultSet resultSet = null;
		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.questions);
			statement.setString(1, segId);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				String polQuesId = resultSet.getString(1);
				int polQuesSeq = resultSet.getInt(2);
				String polQuesDesc = resultSet.getString(4);
				String polQuesAns1 = resultSet.getString(5);
				int polQuesAns1Weightage = resultSet.getInt(6);
				String polQuesAns2 = resultSet.getString(7);
				int polQuesAns2Weightage = resultSet.getInt(8);
				String polQuesAns3 = resultSet.getString(9);
				int polQuesAns3Weightage = resultSet.getInt(10);
				Policy policy = new Policy();
				policy.setPolQuesId(polQuesId);
				policy.setPolQuesSeq(polQuesSeq);
				policy.setPolQuesDesc(polQuesDesc);
				policy.setPolQuesAns1(polQuesAns1);
				policy.setPolQuesAns1Weightage(polQuesAns1Weightage);
				policy.setPolQuesAns2(polQuesAns2);
				policy.setPolQuesAns2Weightage(polQuesAns2Weightage);
				policy.setPolQuesAns3(polQuesAns3);
				policy.setPolQuesAns3Weightage(polQuesAns3Weightage);
				list4.add(policy);
			}
		} catch (SQLException e) {
			System.err.println("SQL STATEMENT DOESNT EXECUTED");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new OiqgsException("proble in closing the statement");
			}
			try {
				connection.close();
			} catch (Exception e2) {
				throw new OiqgsException("connection is not closed");
			}
		}
		return list4;
	}

	@SuppressWarnings("unused")
	@Override
	public long insertPolicy(Policy policy) throws OiqgsException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		boolean valid = false;
		try {
			statement = connection.prepareStatement(QueryMapper.policyInsert);
			statement.setString(1, policy.getBussinessSegment());
			statement.setDouble(2, policy.getPolicyPremium());
			statement.setLong(3, policy.getAccountNumber());
			result = statement.executeUpdate();
			statement = connection.prepareStatement(QueryMapper.policyNumber);
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next())
				accountNum = resultSet.getLong(1);
		} catch (SQLException e) {
			System.err.println("SQL STATEMENT DOESNT EXECUTED");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new OiqgsException("proble in closing the statement");
			}
			try {
				connection.close();
			} catch (Exception e2) {
				throw new OiqgsException("connection is not closed");
			}
		}
		return accountNum;
	}

	@Override
	public int insertPolicyDetails(PolicyDetails details) throws OiqgsException {
		connection = JdbcUtility.getConnection();
		int result = 0;
		try {
			statement = connection.prepareStatement(QueryMapper.policyDetails);
			statement.setLong(1, accountNum);
			statement.setString(2, details.getQuestId());
			statement.setString(3, details.getQuestAns());
			statement.setString(4, details.getPolicyQuestions());
			result = statement.executeUpdate();
		} catch (SQLException e) {
			System.err.println("SQL STATEMENT DOESNT EXECUTED");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new OiqgsException("proble in closing the statement");
			}
			try {
				connection.close();
			} catch (Exception e2) {
				throw new OiqgsException("connection is not closed");
			}
		}
		return result;
	}

	@Override
	public List<Policy> getPolicyDetails(String userName) throws OiqgsException {
		List<Policy> list5 = new ArrayList<>();
		ResultSet resultSet = null;
		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.getPolicyDetails);
			statement.setString(1, userName);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				long policyNumber = resultSet.getLong(1);
				String businessSegment = resultSet.getString(2);
				double policyPremium = resultSet.getDouble(3);
				long accountNumber = resultSet.getLong(4);
				Policy policy = new Policy();
				policy.setPolicyNumber(policyNumber);
				policy.setBussinessSegment(businessSegment);
				policy.setAccountNumber(accountNumber);
				policy.setPolicyPremium(policyPremium);
				list5.add(policy);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list5;
	}

	@Override
	public List<Report> getReport(long accountNumber) throws OiqgsException {
		List<Report> list7 = new ArrayList<>();
		ResultSet resultSet = null;
		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.getReport);
			statement.setLong(1, accountNumber);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				String insuredName = resultSet.getString(1);
				String insuredStreet = resultSet.getString(2);
				String insuredCity = resultSet.getString(3);
				String insuredState = resultSet.getString(4);
				int insuredZip = resultSet.getInt(5);
				String bussinessSegment = resultSet.getString(6);
				String policyQuestion = resultSet.getString(7);
				String questAns = resultSet.getString(8);
				double policyPremium = resultSet.getDouble(9);

				Report report = new Report();
				report.setInsuredName(insuredName);
				report.setInsuredStreet(insuredStreet);
				report.setInsuredCity(insuredCity);
				report.setInsuredState(insuredState);
				report.setInsuredZip(insuredZip);
				report.setBussinessSegment(bussinessSegment);
				report.setPolicyQuestions(policyQuestion);
				report.setQuestAns(questAns);
				report.setPolicyPremium(policyPremium);
				list7.add(report);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list7;
	}

	@Override
	public List<Policy> getPolicyDetails() throws OiqgsException {
		List<Policy> list8 = new ArrayList<>();
		ResultSet resultSet = null;
		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.getAllPolicyDetails);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				long policyNumber = resultSet.getLong(1);
				String businessSegment = resultSet.getString(2);
				double policyPremium = resultSet.getDouble(3);
				long accountNumber = resultSet.getLong(4);
				Policy policy = new Policy();
				policy.setPolicyNumber(policyNumber);
				policy.setBussinessSegment(businessSegment);
				policy.setAccountNumber(accountNumber);
				policy.setPolicyPremium(policyPremium);
				list8.add(policy);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list8;
	}

	@Override
	public boolean checkinsured(String userName) throws OiqgsException {
		ResultSet resultSet = null;
		List<AccountCreation> list6 = new ArrayList<>();
		boolean validFlag = false;
		connection = JdbcUtility.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.checkAccount);
			statement.setString(1, userName);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				String insuredName = resultSet.getString(1);
				AccountCreation accountCreation2 = new AccountCreation();
				accountCreation2.setInsuredName(insuredName);
				list6.add(accountCreation2);
			}
			if (list6.isEmpty()) {
				validFlag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return validFlag;
	}

}
